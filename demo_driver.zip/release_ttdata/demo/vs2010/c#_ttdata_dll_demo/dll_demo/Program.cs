﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.Ports;
using System.Threading;
using System.Management;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;

namespace dll_demo
{
    class Program
    {
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         public delegate void tt_scan_get_data_fun(string pBuf, UInt32 uiBufLen);
         [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
         public delegate void tt_scan_state_fun(byte ucState);

         [DllImport("TT_TTDATA_C++_dll.dll", CallingConvention = CallingConvention.Cdecl)]
         private extern static int tt_scan_init();

         [DllImport("TT_TTDATA_C++_dll.dll", CallingConvention = CallingConvention.Cdecl)]
         private extern static int tt_scan_deinit();

         [DllImport("TT_TTDATA_C++_dll.dll", CallingConvention = CallingConvention.Cdecl)]
         private extern static string tt_scan_get_version();

         [DllImport("TT_TTDATA_C++_dll.dll", CallingConvention = CallingConvention.Cdecl)]
         private extern static int tt_scan_get_data_fun_register(tt_scan_get_data_fun fGetDataFun);

         [DllImport("TT_TTDATA_C++_dll.dll", CallingConvention = CallingConvention.Cdecl)]
         private extern static int tt_scan_state_fun_register(tt_scan_state_fun fStateFun);

         [DllImport("TT_TTDATA_C++_dll.dll", CallingConvention = CallingConvention.Cdecl)]
         private extern static int tt_scan_decode_start();

         [DllImport("TT_TTDATA_C++_dll.dll", CallingConvention = CallingConvention.Cdecl)]
         private extern static int tt_scan_decode_stop();

         [DllImport("TT_TTDATA_C++_dll.dll", CallingConvention = CallingConvention.Cdecl)]
         private extern static int tt_scan_test(byte ucParm);

         static int s_iScanCnt = 0; 
        /**上报解码数据**/
        static void my_scan_decode_data(string pBuf, UInt32 uiBufLen)
        {
            Console.WriteLine("scan data len:{0},num:{1}\r\n{2}", uiBufLen, ++s_iScanCnt, pBuf);
                
            //Console.WriteLine("停止扫码");
            var ret1 = tt_scan_decode_stop();
            //Console.WriteLine(ret1);
            //Console.WriteLine("停止扫码成功");
            Thread.Sleep(1000);

            //Console.WriteLine("开始扫码");
            var ret2 = tt_scan_decode_start();
            //Console.WriteLine(ret2);
            //Console.WriteLine("开始扫码成功");
        }

        /**上报状态,0:设备断开,1:设备连接**/
        static void my_scan_state(byte ucState)
        {
            Console.WriteLine("scan state:{0}", ucState); 
        }
     
        static tt_scan_get_data_fun fScanGetDataFun;
        static tt_scan_state_fun fScanStateFun;
        static void Main(string[] args)
        {
            byte[] BufSn = new byte[64];

            Console.WriteLine("hello tt scan");

            /**注册扫描数据上报函数**/
            fScanGetDataFun = my_scan_decode_data;
            tt_scan_get_data_fun_register(fScanGetDataFun);

            /**注册状态上报函数**/
            fScanStateFun = my_scan_state;
            tt_scan_state_fun_register(fScanStateFun);

            /**初始化**/
            tt_scan_init();

            /**获取扫描模块版本号**/
            Console.WriteLine("tt scan ver:{0}", tt_scan_get_version());

            while (true)
            {
                switch (Console.ReadLine())
                {
                    case "1":
                        /**开始扫描**/
                        tt_scan_decode_start();
                        break;

                    case "2":
                        /**结束扫描**/
                        tt_scan_decode_stop();
                        break;
                }

            }
        }
    }
}
